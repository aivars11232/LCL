#!/bin/sh
# Install LCL for the invoking user.
#
# Writes only under the user's own directories, needs no elevation, and prints
# every path it touches. ./uninstall.sh reverses it exactly.
#
#   ~/.local/bin/lcl                    the command-line tool
#   ~/.local/bin/lcl-workspace          the editor and debugger
#   ~/.local/bin/lcl-workspace-launch   what the desktop entry runs
#   ~/.local/share/lcl/LCL_Core_0.1.0   the specification package they load
#   ~/.local/share/lcl/LCL_Core_0.2.0   the localized-language package, when
#                                       the payload carries one
#   ~/.local/share/applications         the desktop entry
#   ~/.local/share/mime/packages        the .lcl media type
#   ~/.local/share/icons/hicolor/...    the application and document icons
#
# The specification package is installed beside the binaries rather than looked
# for, because the engine loads one exact approved package and "Ambient current
# directory and implied nearby files do not exist in portable LCL".
set -eu

here=$(cd "$(dirname "$0")" && pwd)
bin=${XDG_BIN_HOME:-$HOME/.local/bin}
data=${XDG_DATA_HOME:-$HOME/.local/share}

mkdir -p "$bin" "$data/lcl" "$data/applications" "$data/mime/packages"

# Replace @KEY@ with an exact value, reading standard input.
#
# `awk` rather than `sed`, because a substituted path is arbitrary text: `&` in
# a sed replacement means "the whole match", and a home directory holding one
# would install a launcher pointing somewhere else. The value reaches awk
# through the environment, not `-v`, because `-v` processes backslash escapes
# and would turn a `\t` in a path into a tab. ENVIRON is read as it is, so
# nothing here interprets the value.
substitute() {
    LCL_SUBSTITUTE_VALUE=$2 awk -v key="$1" '
        BEGIN { value = ENVIRON["LCL_SUBSTITUTE_VALUE"] }
        {
            out = ""
            rest = $0
            while ((at = index(rest, key)) > 0) {
                out = out substr(rest, 1, at - 1) value
                rest = substr(rest, at + length(key))
            }
            print out rest
        }'
}

# One desktop-entry argument, quoted as the specification requires.
#
# "Reserved characters are space, tab, newline, double quote, single quote,
# backslash ... and must be escaped with a backslash inside a quoted argument."
# Quoting unconditionally keeps an installation under a path with a space in it
# from silently becoming two arguments.
#
# The value is also a string, and string escapes "are applied before the quoting
# rule", so every backslash the quoting wrote is doubled once more. A literal
# percent sign is written `%%`, because `%f` and its kind are field codes.
desktop_quote() {
    printf '"%s"' "$(printf '%s' "$1" | sed -e 's/[\\"`$]/\\&/g' -e 's/\\/\\\\/g' -e 's/%/%%/g')"
}

# One word a shell reads back as exactly this text: the value in single quotes,
# with each single quote in it written as '\''.
shell_quote() {
    printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\\\''/g")"
}

install -m 0755 "$here/bin/lcl" "$bin/lcl"
install -m 0755 "$here/bin/lcl-workspace" "$bin/lcl-workspace"
echo "installed $bin/lcl"
echo "installed $bin/lcl-workspace"

rm -rf "$data/lcl/LCL_Core_0.1.0"
cp -r "$here/share/LCL_Core_0.1.0" "$data/lcl/LCL_Core_0.1.0"
echo "installed $data/lcl/LCL_Core_0.1.0"

# A 0.2.0 payload also carries the Core 0.2.0 package. The launcher then passes
# it as --localized-spec; with none, the launcher passes nothing extra.
localized=
if [ -d "$here/share/LCL_Core_0.2.0" ]; then
    localized=$data/lcl/LCL_Core_0.2.0
    rm -rf "$localized"
    cp -r "$here/share/LCL_Core_0.2.0" "$localized"
    echo "installed $localized"
fi

# The launcher the desktop entry runs. It carries the installed binary, the
# installed specification package and the default project directory as absolute
# paths, so a menu launch needs no environment at all. Each is written as one
# quoted shell word, so a space or a quote in a path stays part of the path.
substitute '@BIN@' "$(shell_quote "$bin/lcl-workspace")" < "$here/share/lcl-workspace-launch.in" \
    | substitute '@SPEC@' "$(shell_quote "$data/lcl/LCL_Core_0.1.0")" \
    | substitute '@LOCALIZED_SPEC@' "$(shell_quote "$localized")" \
    | substitute '@DEFAULT_PROJECT@' "$(shell_quote "$data/lcl/workspace")" \
    > "$bin/lcl-workspace-launch"
chmod 0755 "$bin/lcl-workspace-launch"
echo "installed $bin/lcl-workspace-launch"

# The desktop entry names that launcher by absolute path, so it does not depend
# on the user's PATH.
substitute '@LAUNCHER@' "$(desktop_quote "$bin/lcl-workspace-launch")" \
    < "$here/share/lcl.desktop" > "$data/applications/lcl-workspace.desktop"
chmod 0644 "$data/applications/lcl-workspace.desktop"
echo "installed $data/applications/lcl-workspace.desktop"

cp "$here/share/lcl.xml" "$data/mime/packages/lcl.xml"
echo "installed $data/mime/packages/lcl.xml"

# The application icon the desktop entry names, and the document icon for the
# media type registered above. Both are derived from one supplied master, so a
# launcher and the files it opens look like one product.
#
# Each file is copied individually into the shared hicolor theme. The theme
# belongs to every application on the machine, so nothing here creates, empties
# or removes a directory that is not ours to touch, and uninstall removes
# exactly the files this loop wrote.
icons=$data/icons/hicolor
for source in "$here/share/icons/hicolor/"*/*/*.png; do
    [ -f "$source" ] || continue
    relative=${source#"$here/share/icons/hicolor/"}
    mkdir -p "$icons/$(dirname "$relative")"
    cp "$source" "$icons/$relative"
done
echo "installed $icons/*/apps/lcl-workspace.png"
echo "installed $icons/*/mimetypes/text-x-lcl.png"

# No icon cache is generated. `gtk-update-icon-cache` writes an
# `icon-theme.cache` into the theme root, which is a lookup accelerator rather
# than a requirement: the icon theme specification's search algorithm reads the
# directories, and every desktop falls back to doing so. Generating one would
# put a shared file into the theme that this installation did not own and could
# not safely remove, and the icons resolve without it.

if command -v update-mime-database >/dev/null 2>&1; then
    update-mime-database "$data/mime"
    echo "updated   $data/mime"
else
    echo "note: update-mime-database is absent, so the .lcl media type is not registered" >&2
fi
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$data/applications" >/dev/null 2>&1 || true
fi

echo
echo "The desktop entry opens the workspace through:"
echo "    $bin/lcl-workspace-launch"
echo "With no document it opens $data/lcl/workspace; uninstall never removes that."
echo
echo "Every command needs the specification package. It is installed at:"
echo "    $data/lcl/LCL_Core_0.1.0"
echo
echo "Point a command at it with --spec, or export LCL_SPEC:"
echo "    export LCL_SPEC=$data/lcl/LCL_Core_0.1.0"
echo
if [ -n "$localized" ]; then
    echo "Localized (LCL 0.2.0) documents also need the 0.2.0 package:"
    echo "    export LCL_LOCALIZED_SPEC=$localized"
    echo
fi
case ":$PATH:" in
    *":$bin:"*) ;;
    *) echo "note: $bin is not on your PATH." ;;
esac
