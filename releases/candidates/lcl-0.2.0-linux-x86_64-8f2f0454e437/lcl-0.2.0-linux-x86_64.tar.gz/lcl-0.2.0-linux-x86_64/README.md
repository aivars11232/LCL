# LCL, packaged

Two binaries, a desktop launcher, the specification package they load, a
desktop entry and a media type. Everything installs under your own home
directory.

## Install

```sh
./install.sh
```

It needs no elevation, writes nothing system-wide, and prints every path it
touches. `./uninstall.sh` removes everything it installed. The one thing
uninstall keeps is `~/.local/share/lcl/workspace`, because that directory holds
your own documents rather than ours.

## From the desktop

The installed menu entry runs `~/.local/bin/lcl-workspace-launch`, not the
binary directly. The script exists because one `Exec` line cannot express three
things a menu launch needs.

- **The specification package.** Nothing searches for one, so the installer
  writes its absolute path into the launcher. A menu launch therefore works
  with no `LCL_SPEC` exported.
- **The browser.** A desktop launch has no terminal, so the URL the workspace
  prints would go nowhere. The launcher passes `--open`.
- **The document.** A file association hands over a *file*; the workspace's
  positional argument is a *project directory*. The launcher passes the file to
  `--document`, which resolves its own project: the nearest ancestor holding
  `lcl.project.json`, or the file's own directory.

Opened from the menu with no document, it opens
`~/.local/share/lcl/workspace`, stated rather than inherited from wherever the
process happened to start.

A 0.2.0 installation also passes the Core 0.2.0 package, but no locale
profile: none is installed, and nothing searches for one. A localized document
gets its profiles from its project. Put the `<locale>.json` files in a
directory and name it in `lcl.project.json`, relative to the project root:

```json
{ "format": "lcl.project/1", "spec": "…", "profiles": "profiles" }
```

Without that a document that needs a profile is refused with
`error.localization.profile_unavailable`, never read with canonical spellings.
From a terminal, `lcl-workspace --profile <file>` and `lcl --profile <file>`
add a profile file after the project's directory, by the same rule.

Anything that goes wrong is written to
`~/.local/state/lcl/launch.log` and, where a dialog tool exists, shown in one.
A launch that fails is not a launch that silently does nothing.

Installing registers the `text/x-lcl` media type and an application that
handles it. It does **not** make LCL your default handler for anything; that
stays your choice.

## Icons

The menu entry and `.lcl` documents both use the supplied LCL mark, installed
into `~/.local/share/icons/hicolor` at seven sizes. Both come from one master,
recorded with its checksum in `assets/brand/`.

The theme directory is shared with every other application, so the installer
copies its own files in one at a time and the uninstaller removes exactly those
files. Neither ever removes a directory it did not fill, the shared `icons/`
and `icons/hicolor/` roots are never removed even when empty, and no icon cache is
generated: the icon theme specification resolves an icon by reading the
directories, and writing a cache would put a shared file there that this
installation could not safely take back.

Setting a menu icon does not change the icon of the browser window the
workspace opens in. That window belongs to your browser.

## The one thing to know

Every command needs a specification package, and **nothing searches for one**.
`05_SEMANTICS/02` puts it plainly: "Ambient current directory and implied
nearby files do not exist in portable LCL." So the package travels with the
binaries and you name it, once:

```sh
export LCL_SPEC=~/.local/share/lcl/LCL_Core_0.1.0
# a 0.2.0 candidate also installs the localized-language package:
export LCL_LOCALIZED_SPEC=~/.local/share/lcl/LCL_Core_0.2.0
```

or per command with `--spec`, or per project in `lcl.project.json`.

## Use

```sh
lcl help                      # commands, options and exit codes
lcl version                   # tool, protocol and the languages it can judge
lcl spec                      # the package identity and whether it is authoritative
lcl check   src/main.lcl      # canonical steps 1 to 5
lcl validate src/main.lcl     # steps 1 to 9, before any effect
lcl run     src/main.lcl      # steps 1 to 13, one terminal status
lcl run --allow-write /tmp/out src/main.lcl    # the same, with one capability
lcl check --machine src/main.lcl               # the JSON a tool consumes
lcl-workspace my-project --open                # the editor and debugger
lcl-workspace --document src/main.lcl --open   # open one document's project
```

## What a document is called

New documents are created as `name.lcl.txt`, so they can be shared, opened and
edited anywhere plain text is. Both endings are recognised everywhere: the
project tree, opening, saving, checking, running and the `.lcl` file
association. Nothing renames an existing document, and saving writes exactly
the name it opened.

The ending decides nothing about meaning. A `.lcl.txt` document is judged by the
same engine under the same contracts as a `.lcl` one, and ending a name in
`.txt` never relaxes validation. Ordinary `.txt` files are not LCL documents.

A run is granted nothing unless a flag says so. A document that asks for the
world against a tool that was granted nothing gets a refusal, not a surprise.

## Exit codes

| Code | Meaning |
| --- | --- |
| 0 | the requested work completed, and for `run` the terminal status was `status.succeeded` |
| 1 | the document was rejected by a diagnostic |
| 2 | the document ran to completion with a non-success terminal status |
| 3 | the command line was not usable |
| 4 | the environment was not usable: no package, an unreadable document, a project that would not open |

`1` and `2` are deliberately different. A program that failed its own `VERIFY`
ran correctly and did not succeed, which `05_SEMANTICS/10` treats as an
ordinary outcome rather than an error.

## Building this yourself

```sh
packaging/build_release.sh
```

It lists the source, records every file's mode, size and SHA-256 in
`SOURCE_INVENTORY.tsv`, archives exactly those bytes, and builds `--release
--offline --locked` from a snapshot unpacked from that archive and checked
against the inventory, never from the live checkout. The candidate goes to
`releases/candidates/<name>-<source id>`, or to `LCL_RELEASE_OUT`, which must
not exist yet: nothing is ever written into or over an existing directory.
Beside the payload tarball and its checksum it writes the source archive, the
inventory and a provenance record naming the source id, the commit and
uncommitted entries of a checkout, the toolchain, the package identity and the
checksum of every file in the payload.

A build that fails says so, publishes nothing, and keeps its working directory,
whose path it prints, as evidence.

To rebuild from a source archive, with no Git history:

```sh
tar -xzOf lcl-<version>-linux-x86_64-source.tar.gz packaging/build_release.sh > build_release.sh
sh build_release.sh --reconstruct lcl-<version>-linux-x86_64-source.tar.gz <new directory>
cd <new directory> && LCL_RELEASE_OUT=<new output directory> packaging/build_release.sh
```

`--reconstruct` refuses an archive that holds anything but the regular files
its inventory names, before extracting anything. Rebuilt binaries are not
promised to be bit-for-bit identical; the source they were built from is.

## Release version

`LCL_RELEASE_VERSION=0.2.0 packaging/build_release.sh` builds a separate
`lcl-0.2.0-linux-x86_64` candidate. It bundles the Core 0.1.0 package and the
Core 0.2.0 package: `install.sh` installs both, the desktop launcher passes the
0.2.0 package as `--localized-spec`, and the provenance records both package
identities. Without the variable the release version is the product version in
`impl/Cargo.toml`, and a 0.1.0 candidate is built exactly as before. No other
value is accepted.

`lcl version` names Core 0.2.0 only when a Core 0.2.0 package is named to it,
by `--localized-spec` or `LCL_LOCALIZED_SPEC`, and that package opens. The
provenance's language version is what the built `lcl version` reports with
exactly the packages the payload carries, and a candidate whose tool reports
any other set is refused.
